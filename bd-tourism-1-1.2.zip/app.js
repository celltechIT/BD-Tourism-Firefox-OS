$(document).ready(function(){

	   $("#btnSMS").click(function(){
	      var newSMS = new MozActivity({
				name: "new",
				data: {
				    type : "websms/sms",
					number: "1200",
					body: "TKET"
				}
			});
		});

			   });